/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with

 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.gluten.memory.memtarget;

import org.apache.gluten.proto.MemoryUsageStats;

/**
 * The implementation provides a String name and {@link MemoryUsageStats}.
 *
 * <p>The API is used to format the dumped message when utility method {@link
 * org.apache.spark.memory.SparkMemoryUtil#dumpMemoryTargetStats} is called.
 */
public interface KnownNameAndStats {
  String name();

  MemoryUsageStats stats();
}
