/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with

 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.gluten.substrait.rel;

import com.google.protobuf.Message;

import java.io.Serializable;
import java.util.List;

/**
 * A serializable representation of a read split for native engine, including the file path and
 * other information of the scan table. It is returned by {@link
 * org.apache.gluten.execution.BasicScanExecTransformer#getSplitInfos()}.
 */
public interface SplitInfo extends Serializable {
  /** The preferred locations where the table files returned by this read split can run faster. */
  List<String> preferredLocations();

  Message toProtobuf();
}
