/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with

 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.gluten.substrait.type;

import io.substrait.proto.Type;

public class BooleanTypeNode extends TypeNode {

  public BooleanTypeNode(Boolean nullable) {
    super(nullable);
  }

  @Override
  public Type toProtobuf() {
    Type.Boolean.Builder booleanBuilder = Type.Boolean.newBuilder();
    if (nullable) {
      booleanBuilder.setNullability(Type.Nullability.NULLABILITY_NULLABLE);
    } else {
      booleanBuilder.setNullability(Type.Nullability.NULLABILITY_REQUIRED);
    }

    Type.Builder builder = Type.newBuilder();
    builder.setBool(booleanBuilder.build());
    return builder.build();
  }
}
